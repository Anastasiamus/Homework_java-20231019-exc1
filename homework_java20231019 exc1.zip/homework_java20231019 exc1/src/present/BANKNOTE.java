package present;

public enum BANKNOTE {
    FIFTEY,
    HUNDERT,
    TWOHUNDERT,
    FIVEHUNDERT


}
